# Restauranking MVP
Proyecto base con Next.js y Tailwind.